const Footer = ({footer}) => {
    return <footer><p><small>{footer}</small></p></footer>;
}

export default Footer;