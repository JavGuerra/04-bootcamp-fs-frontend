const Zone = () => {
    return (
        <dialog id="zone">
            <div className="spinner" aria-label="Consultando..."></div>
        </dialog>
    );
}

export default Zone;