import { useContext } from "react";
import Config from "../contexts/ConfigContext";

export default () => useContext(Config);